﻿Public Class AdminLogin

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim password As String = TextBox1.Text

        If password = "Admin" Then
            MDIParentAdmin.Show()

        Else
            MessageBox.Show("Access Denied")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        LoginForm.Show()
        Me.Close()

    End Sub
End Class