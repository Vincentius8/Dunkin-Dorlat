﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cashier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Cashier))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnC = New System.Windows.Forms.Button()
        Me.BtnDot = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BtnExportToExcel = New System.Windows.Forms.Button()
        Me.btnPj = New System.Windows.Forms.Button()
        Me.btnMj = New System.Windows.Forms.Button()
        Me.btnOj = New System.Windows.Forms.Button()
        Me.btnEac = New System.Windows.Forms.Button()
        Me.btnTs = New System.Windows.Forms.Button()
        Me.btnS = New System.Windows.Forms.Button()
        Me.btnCg = New System.Windows.Forms.Button()
        Me.btnSr = New System.Windows.Forms.Button()
        Me.btnBf = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnSl = New System.Windows.Forms.Button()
        Me.btnCl = New System.Windows.Forms.Button()
        Me.btnSs = New System.Windows.Forms.Button()
        Me.btnCbnm = New System.Windows.Forms.Button()
        Me.btnHnc = New System.Windows.Forms.Button()
        Me.btnQd = New System.Windows.Forms.Button()
        Me.btnBbc = New System.Windows.Forms.Button()
        Me.btnCB = New System.Windows.Forms.Button()
        Me.btnNc = New System.Windows.Forms.Button()
        Me.btnCm = New System.Windows.Forms.Button()
        Me.btnBk = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BtnRemove = New System.Windows.Forms.Button()
        Me.BtnPrint = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.BtnPay = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblChange = New System.Windows.Forms.Label()
        Me.lblCash = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboPayment = New System.Windows.Forms.ComboBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.lblSubTotal = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Itm = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.CashierName = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Choices = New System.Windows.Forms.ComboBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.btnC)
        Me.Panel1.Controls.Add(Me.BtnDot)
        Me.Panel1.Controls.Add(Me.btn0)
        Me.Panel1.Controls.Add(Me.btn3)
        Me.Panel1.Controls.Add(Me.btn2)
        Me.Panel1.Controls.Add(Me.btn1)
        Me.Panel1.Controls.Add(Me.btn6)
        Me.Panel1.Controls.Add(Me.btn5)
        Me.Panel1.Controls.Add(Me.btn4)
        Me.Panel1.Controls.Add(Me.btn9)
        Me.Panel1.Controls.Add(Me.btn8)
        Me.Panel1.Controls.Add(Me.btn7)
        Me.Panel1.Location = New System.Drawing.Point(27, 209)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(319, 384)
        Me.Panel1.TabIndex = 0
        '
        'btnC
        '
        Me.btnC.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnC.Location = New System.Drawing.Point(213, 282)
        Me.btnC.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(99, 87)
        Me.btnC.TabIndex = 0
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'BtnDot
        '
        Me.BtnDot.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDot.Location = New System.Drawing.Point(108, 282)
        Me.BtnDot.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnDot.Name = "BtnDot"
        Me.BtnDot.Size = New System.Drawing.Size(99, 87)
        Me.BtnDot.TabIndex = 0
        Me.BtnDot.Text = "."
        Me.BtnDot.UseVisualStyleBackColor = True
        '
        'btn0
        '
        Me.btn0.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.Location = New System.Drawing.Point(3, 282)
        Me.btn0.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(99, 87)
        Me.btn0.TabIndex = 0
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(213, 190)
        Me.btn3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(99, 87)
        Me.btn3.TabIndex = 0
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(108, 190)
        Me.btn2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(99, 87)
        Me.btn2.TabIndex = 0
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(3, 190)
        Me.btn1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(99, 87)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Location = New System.Drawing.Point(213, 96)
        Me.btn6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(99, 87)
        Me.btn6.TabIndex = 5
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Location = New System.Drawing.Point(108, 96)
        Me.btn5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(99, 87)
        Me.btn5.TabIndex = 4
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Location = New System.Drawing.Point(3, 96)
        Me.btn4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(99, 87)
        Me.btn4.TabIndex = 3
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Location = New System.Drawing.Point(213, 2)
        Me.btn9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(99, 87)
        Me.btn9.TabIndex = 0
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Location = New System.Drawing.Point(108, 2)
        Me.btn8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(99, 87)
        Me.btn8.TabIndex = 0
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Location = New System.Drawing.Point(3, 2)
        Me.btn7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(99, 87)
        Me.btn7.TabIndex = 0
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.BtnExportToExcel)
        Me.Panel2.Controls.Add(Me.btnPj)
        Me.Panel2.Controls.Add(Me.btnMj)
        Me.Panel2.Controls.Add(Me.btnOj)
        Me.Panel2.Controls.Add(Me.btnEac)
        Me.Panel2.Controls.Add(Me.btnTs)
        Me.Panel2.Controls.Add(Me.btnS)
        Me.Panel2.Controls.Add(Me.btnCg)
        Me.Panel2.Controls.Add(Me.btnSr)
        Me.Panel2.Controls.Add(Me.btnBf)
        Me.Panel2.Controls.Add(Me.btnA)
        Me.Panel2.Controls.Add(Me.btnSl)
        Me.Panel2.Controls.Add(Me.btnCl)
        Me.Panel2.Controls.Add(Me.btnSs)
        Me.Panel2.Controls.Add(Me.btnCbnm)
        Me.Panel2.Controls.Add(Me.btnHnc)
        Me.Panel2.Controls.Add(Me.btnQd)
        Me.Panel2.Controls.Add(Me.btnBbc)
        Me.Panel2.Controls.Add(Me.btnCB)
        Me.Panel2.Controls.Add(Me.btnNc)
        Me.Panel2.Controls.Add(Me.btnCm)
        Me.Panel2.Controls.Add(Me.btnBk)
        Me.Panel2.Location = New System.Drawing.Point(777, 204)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(684, 482)
        Me.Panel2.TabIndex = 1
        '
        'BtnExportToExcel
        '
        Me.BtnExportToExcel.Location = New System.Drawing.Point(460, 423)
        Me.BtnExportToExcel.Name = "BtnExportToExcel"
        Me.BtnExportToExcel.Size = New System.Drawing.Size(75, 39)
        Me.BtnExportToExcel.TabIndex = 33
        Me.BtnExportToExcel.Text = "Export"
        Me.BtnExportToExcel.UseVisualStyleBackColor = True
        '
        'btnPj
        '
        Me.btnPj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPj.Location = New System.Drawing.Point(215, 375)
        Me.btnPj.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnPj.Name = "btnPj"
        Me.btnPj.Size = New System.Drawing.Size(99, 87)
        Me.btnPj.TabIndex = 29
        Me.btnPj.Text = "Pineapple Juice"
        Me.btnPj.UseVisualStyleBackColor = True
        '
        'btnMj
        '
        Me.btnMj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMj.Location = New System.Drawing.Point(109, 375)
        Me.btnMj.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMj.Name = "btnMj"
        Me.btnMj.Size = New System.Drawing.Size(99, 87)
        Me.btnMj.TabIndex = 30
        Me.btnMj.Text = "Mango Juice"
        Me.btnMj.UseVisualStyleBackColor = True
        '
        'btnOj
        '
        Me.btnOj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOj.Location = New System.Drawing.Point(5, 375)
        Me.btnOj.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnOj.Name = "btnOj"
        Me.btnOj.Size = New System.Drawing.Size(99, 87)
        Me.btnOj.TabIndex = 31
        Me.btnOj.Text = "Orange Juice"
        Me.btnOj.UseVisualStyleBackColor = True
        '
        'btnEac
        '
        Me.btnEac.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEac.Location = New System.Drawing.Point(424, 190)
        Me.btnEac.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnEac.Name = "btnEac"
        Me.btnEac.Size = New System.Drawing.Size(99, 87)
        Me.btnEac.TabIndex = 22
        Me.btnEac.Text = "Egg And Cheese"
        Me.btnEac.UseVisualStyleBackColor = True
        '
        'btnTs
        '
        Me.btnTs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTs.Location = New System.Drawing.Point(319, 190)
        Me.btnTs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTs.Name = "btnTs"
        Me.btnTs.Size = New System.Drawing.Size(99, 87)
        Me.btnTs.TabIndex = 23
        Me.btnTs.Text = "Tuna Sandwich"
        Me.btnTs.UseVisualStyleBackColor = True
        '
        'btnS
        '
        Me.btnS.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnS.Location = New System.Drawing.Point(424, 96)
        Me.btnS.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnS.Name = "btnS"
        Me.btnS.Size = New System.Drawing.Size(99, 87)
        Me.btnS.TabIndex = 28
        Me.btnS.Text = "Sansribav"
        Me.btnS.UseVisualStyleBackColor = True
        '
        'btnCg
        '
        Me.btnCg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCg.Location = New System.Drawing.Point(319, 96)
        Me.btnCg.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCg.Name = "btnCg"
        Me.btnCg.Size = New System.Drawing.Size(99, 87)
        Me.btnCg.TabIndex = 27
        Me.btnCg.Text = "Choco Glazed"
        Me.btnCg.UseVisualStyleBackColor = True
        '
        'btnSr
        '
        Me.btnSr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSr.Location = New System.Drawing.Point(424, 2)
        Me.btnSr.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSr.Name = "btnSr"
        Me.btnSr.Size = New System.Drawing.Size(99, 87)
        Me.btnSr.TabIndex = 25
        Me.btnSr.Text = "Sugar Raised"
        Me.btnSr.UseVisualStyleBackColor = True
        '
        'btnBf
        '
        Me.btnBf.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBf.Location = New System.Drawing.Point(319, 2)
        Me.btnBf.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBf.Name = "btnBf"
        Me.btnBf.Size = New System.Drawing.Size(99, 87)
        Me.btnBf.TabIndex = 26
        Me.btnBf.Text = "Bavarian Filled"
        Me.btnBf.UseVisualStyleBackColor = True
        '
        'btnA
        '
        Me.btnA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnA.Location = New System.Drawing.Point(215, 282)
        Me.btnA.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(99, 87)
        Me.btnA.TabIndex = 6
        Me.btnA.Text = "Americcano"
        Me.btnA.UseVisualStyleBackColor = True
        '
        'btnSl
        '
        Me.btnSl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSl.Location = New System.Drawing.Point(109, 282)
        Me.btnSl.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSl.Name = "btnSl"
        Me.btnSl.Size = New System.Drawing.Size(99, 87)
        Me.btnSl.TabIndex = 7
        Me.btnSl.Text = "Spanish Latte"
        Me.btnSl.UseVisualStyleBackColor = True
        '
        'btnCl
        '
        Me.btnCl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCl.Location = New System.Drawing.Point(5, 282)
        Me.btnCl.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCl.Name = "btnCl"
        Me.btnCl.Size = New System.Drawing.Size(99, 87)
        Me.btnCl.TabIndex = 8
        Me.btnCl.Text = "Caffe Latte"
        Me.btnCl.UseVisualStyleBackColor = True
        '
        'btnSs
        '
        Me.btnSs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSs.Location = New System.Drawing.Point(215, 190)
        Me.btnSs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSs.Name = "btnSs"
        Me.btnSs.Size = New System.Drawing.Size(99, 87)
        Me.btnSs.TabIndex = 9
        Me.btnSs.Text = "Spanish Sausage"
        Me.btnSs.UseVisualStyleBackColor = True
        '
        'btnCbnm
        '
        Me.btnCbnm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCbnm.Location = New System.Drawing.Point(109, 190)
        Me.btnCbnm.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCbnm.Name = "btnCbnm"
        Me.btnCbnm.Size = New System.Drawing.Size(99, 87)
        Me.btnCbnm.TabIndex = 10
        Me.btnCbnm.Text = "ChzBcn N Mushroom"
        Me.btnCbnm.UseVisualStyleBackColor = True
        '
        'btnHnc
        '
        Me.btnHnc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHnc.Location = New System.Drawing.Point(5, 190)
        Me.btnHnc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnHnc.Name = "btnHnc"
        Me.btnHnc.Size = New System.Drawing.Size(99, 87)
        Me.btnHnc.TabIndex = 11
        Me.btnHnc.Text = "Ham" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cheese" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnHnc.UseVisualStyleBackColor = True
        '
        'btnQd
        '
        Me.btnQd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQd.Location = New System.Drawing.Point(215, 96)
        Me.btnQd.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnQd.Name = "btnQd"
        Me.btnQd.Size = New System.Drawing.Size(99, 87)
        Me.btnQd.TabIndex = 17
        Me.btnQd.Text = "Quezo Duo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnQd.UseVisualStyleBackColor = True
        '
        'btnBbc
        '
        Me.btnBbc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBbc.Location = New System.Drawing.Point(109, 96)
        Me.btnBbc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBbc.Name = "btnBbc"
        Me.btnBbc.Size = New System.Drawing.Size(99, 87)
        Me.btnBbc.TabIndex = 16
        Me.btnBbc.Text = "Blueberry" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cheesecake" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnBbc.UseVisualStyleBackColor = True
        '
        'btnCB
        '
        Me.btnCB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCB.Location = New System.Drawing.Point(5, 96)
        Me.btnCB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCB.Name = "btnCB"
        Me.btnCB.Size = New System.Drawing.Size(99, 87)
        Me.btnCB.TabIndex = 15
        Me.btnCB.Text = "Choco" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Butternut"
        Me.btnCB.UseVisualStyleBackColor = True
        '
        'btnNc
        '
        Me.btnNc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNc.Location = New System.Drawing.Point(215, 2)
        Me.btnNc.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNc.Name = "btnNc"
        Me.btnNc.Size = New System.Drawing.Size(99, 87)
        Me.btnNc.TabIndex = 12
        Me.btnNc.Text = "Nutty" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Choco"
        Me.btnNc.UseVisualStyleBackColor = True
        '
        'btnCm
        '
        Me.btnCm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCm.Location = New System.Drawing.Point(109, 2)
        Me.btnCm.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCm.Name = "btnCm"
        Me.btnCm.Size = New System.Drawing.Size(99, 87)
        Me.btnCm.TabIndex = 13
        Me.btnCm.Text = "Choco" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Marble" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnCm.UseVisualStyleBackColor = True
        '
        'btnBk
        '
        Me.btnBk.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBk.Location = New System.Drawing.Point(5, 2)
        Me.btnBk.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBk.Name = "btnBk"
        Me.btnBk.Size = New System.Drawing.Size(99, 87)
        Me.btnBk.TabIndex = 14
        Me.btnBk.Text = "Boston" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Kreme" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnBk.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"COM 1", "COM 2", "COM 3", "COM 4"})
        Me.ComboBox1.Location = New System.Drawing.Point(602, 628)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.ComboBox1.TabIndex = 32
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Maroon
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Button1)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Panel3)
        Me.Panel4.Controls.Add(Me.Panel6)
        Me.Panel4.Location = New System.Drawing.Point(15, 682)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1601, 379)
        Me.Panel4.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1284, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 154)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Silver
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.BtnRemove)
        Me.Panel5.Controls.Add(Me.BtnPrint)
        Me.Panel5.Controls.Add(Me.BtnReset)
        Me.Panel5.Controls.Add(Me.BtnPay)
        Me.Panel5.Location = New System.Drawing.Point(853, 2)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(425, 154)
        Me.Panel5.TabIndex = 3
        '
        'BtnRemove
        '
        Me.BtnRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRemove.Location = New System.Drawing.Point(215, 76)
        Me.BtnRemove.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnRemove.Name = "BtnRemove"
        Me.BtnRemove.Size = New System.Drawing.Size(203, 71)
        Me.BtnRemove.TabIndex = 12
        Me.BtnRemove.Text = "Remove Item"
        Me.BtnRemove.UseVisualStyleBackColor = True
        '
        'BtnPrint
        '
        Me.BtnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPrint.Location = New System.Drawing.Point(5, 76)
        Me.BtnPrint.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Size = New System.Drawing.Size(204, 71)
        Me.BtnPrint.TabIndex = 13
        Me.BtnPrint.Text = "Print"
        Me.BtnPrint.UseVisualStyleBackColor = True
        '
        'BtnReset
        '
        Me.BtnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReset.Location = New System.Drawing.Point(215, -2)
        Me.BtnReset.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(203, 71)
        Me.BtnReset.TabIndex = 10
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = True
        '
        'BtnPay
        '
        Me.BtnPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPay.Location = New System.Drawing.Point(5, -2)
        Me.BtnPay.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnPay.Name = "BtnPay"
        Me.BtnPay.Size = New System.Drawing.Size(204, 71)
        Me.BtnPay.TabIndex = 11
        Me.BtnPay.Text = "Pay"
        Me.BtnPay.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Silver
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.lblChange)
        Me.Panel3.Controls.Add(Me.lblCash)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.cboPayment)
        Me.Panel3.Location = New System.Drawing.Point(416, 2)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(420, 154)
        Me.Panel3.TabIndex = 3
        '
        'lblChange
        '
        Me.lblChange.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblChange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblChange.Location = New System.Drawing.Point(225, 92)
        Me.lblChange.Name = "lblChange"
        Me.lblChange.Size = New System.Drawing.Size(179, 42)
        Me.lblChange.TabIndex = 5
        '
        'lblCash
        '
        Me.lblCash.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblCash.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCash.Location = New System.Drawing.Point(225, 43)
        Me.lblCash.Name = "lblCash"
        Me.lblCash.Size = New System.Drawing.Size(179, 38)
        Me.lblCash.TabIndex = 4
        Me.lblCash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 98)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 36)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Change"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 27)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Amount"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 27)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Method of Payment"
        '
        'cboPayment
        '
        Me.cboPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPayment.FormattingEnabled = True
        Me.cboPayment.Location = New System.Drawing.Point(225, 1)
        Me.cboPayment.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cboPayment.Name = "cboPayment"
        Me.cboPayment.Size = New System.Drawing.Size(177, 33)
        Me.cboPayment.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Silver
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.lblSubTotal)
        Me.Panel6.Controls.Add(Me.Label11)
        Me.Panel6.Controls.Add(Me.lblTotal)
        Me.Panel6.Controls.Add(Me.lblTax)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.Label9)
        Me.Panel6.Location = New System.Drawing.Point(12, 2)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(396, 150)
        Me.Panel6.TabIndex = 2
        '
        'lblSubTotal
        '
        Me.lblSubTotal.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubTotal.Location = New System.Drawing.Point(121, 9)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(179, 38)
        Me.lblSubTotal.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(3, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 38)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "SubTotal"
        '
        'lblTotal
        '
        Me.lblTotal.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal.Location = New System.Drawing.Point(121, 103)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(179, 42)
        Me.lblTotal.TabIndex = 9
        '
        'lblTax
        '
        Me.lblTax.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTax.Location = New System.Drawing.Point(121, 54)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(179, 38)
        Me.lblTax.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 107)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 38)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Total"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 54)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 38)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Tax"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Itm, Me.Qty, Me.Amt})
        Me.DataGridView1.Location = New System.Drawing.Point(352, 209)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(420, 414)
        Me.DataGridView1.TabIndex = 3
        '
        'Itm
        '
        Me.Itm.HeaderText = "Item"
        Me.Itm.Name = "Itm"
        '
        'Qty
        '
        Me.Qty.HeaderText = "Quantity"
        Me.Qty.Name = "Qty"
        '
        'Amt
        '
        Me.Amt.HeaderText = "Amount"
        Me.Amt.Name = "Amt"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(720, 28)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(204, 31)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Dunk N' Dorlat"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(703, 73)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(244, 85)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "                  LFP  Food Corp" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " VAT REG TIN: 032-698-2364-3200" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "            TR" & _
    "IMEX TROJAN BLDG" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "COR GEN CAPINPIN BINAN LAGUNA" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "             LFP Service POS V4" & _
    ".0"
        '
        'PrintDocument1
        '
        '
        'CashierName
        '
        Me.CashierName.FormattingEnabled = True
        Me.CashierName.Items.AddRange(New Object() {"Cashier1", "Casher2", "Cashier3"})
        Me.CashierName.Location = New System.Drawing.Point(352, 628)
        Me.CashierName.Name = "CashierName"
        Me.CashierName.Size = New System.Drawing.Size(121, 24)
        Me.CashierName.TabIndex = 6
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(930, 177)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(258, 22)
        Me.DateTimePicker1.TabIndex = 7
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.DateTimePicker2.Location = New System.Drawing.Point(1188, 177)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(107, 22)
        Me.DateTimePicker2.TabIndex = 8
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Choices
        '
        Me.Choices.FormattingEnabled = True
        Me.Choices.Items.AddRange(New Object() {"Dine In", "Take Home"})
        Me.Choices.Location = New System.Drawing.Point(54, 628)
        Me.Choices.Name = "Choices"
        Me.Choices.Size = New System.Drawing.Size(121, 24)
        Me.Choices.TabIndex = 9
        '
        'Cashier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(1568, 874)
        Me.Controls.Add(Me.Choices)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.CashierName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Cashier"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cashier"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents btnC As System.Windows.Forms.Button
    Friend WithEvents BtnDot As System.Windows.Forms.Button
    Friend WithEvents btn0 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn6 As System.Windows.Forms.Button
    Friend WithEvents btn5 As System.Windows.Forms.Button
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn9 As System.Windows.Forms.Button
    Friend WithEvents btn8 As System.Windows.Forms.Button
    Friend WithEvents btn7 As System.Windows.Forms.Button
    Friend WithEvents btnEac As System.Windows.Forms.Button
    Friend WithEvents btnTs As System.Windows.Forms.Button
    Friend WithEvents btnS As System.Windows.Forms.Button
    Friend WithEvents btnCg As System.Windows.Forms.Button
    Friend WithEvents btnSr As System.Windows.Forms.Button
    Friend WithEvents btnBf As System.Windows.Forms.Button
    Friend WithEvents btnA As System.Windows.Forms.Button
    Friend WithEvents btnSl As System.Windows.Forms.Button
    Friend WithEvents btnCl As System.Windows.Forms.Button
    Friend WithEvents btnSs As System.Windows.Forms.Button
    Friend WithEvents btnCbnm As System.Windows.Forms.Button
    Friend WithEvents btnHnc As System.Windows.Forms.Button
    Friend WithEvents btnQd As System.Windows.Forms.Button
    Friend WithEvents btnBbc As System.Windows.Forms.Button
    Friend WithEvents btnCB As System.Windows.Forms.Button
    Friend WithEvents btnNc As System.Windows.Forms.Button
    Friend WithEvents btnCm As System.Windows.Forms.Button
    Friend WithEvents btnBk As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Itm As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnPj As System.Windows.Forms.Button
    Friend WithEvents btnMj As System.Windows.Forms.Button
    Friend WithEvents btnOj As System.Windows.Forms.Button
    Friend WithEvents BtnRemove As System.Windows.Forms.Button
    Friend WithEvents BtnPrint As System.Windows.Forms.Button
    Friend WithEvents BtnReset As System.Windows.Forms.Button
    Friend WithEvents BtnPay As System.Windows.Forms.Button
    Friend WithEvents lblChange As System.Windows.Forms.Label
    Friend WithEvents lblCash As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboPayment As System.Windows.Forms.ComboBox
    Friend WithEvents lblSubTotal As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents lblTax As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents CashierName As System.Windows.Forms.ComboBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Choices As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents BtnExportToExcel As System.Windows.Forms.Button

End Class
