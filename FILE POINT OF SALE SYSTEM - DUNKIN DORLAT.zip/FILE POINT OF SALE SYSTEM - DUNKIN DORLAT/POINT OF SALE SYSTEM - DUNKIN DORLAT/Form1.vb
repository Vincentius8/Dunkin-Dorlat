﻿Imports System.Drawing.Printing
Imports OfficeOpenXml
Imports System.IO
Public Class Cashier
    Private bitmap As Bitmap
    Dim WithEvents PD As New PrintDocument
    Dim PPD As New PrintPreviewDialog
    Dim longpaper As Integer





    Private Function Cost_of_Item() As Double

        Dim Sum As Double = 0
        Dim i As Integer = 0

        For i = 0 To DataGridView1.Rows.Count - 1

            Sum = Sum + Convert.ToDouble(DataGridView1.Rows(i).Cells(2).Value)

        Next i
        Return Sum
    End Function

    Sub AddCost()
        Dim tax, q As Double
        tax = 2.0

        If DataGridView1.Rows.Count > 0 Then
            lblSubTotal.Text = (Cost_of_Item().ToString("0.00"))
            lblTax.Text = FormatCurrency(((Cost_of_Item() * tax) / 100).ToString("0.00"))

            q = ((Cost_of_Item() * tax) / 100)

            lblTotal.Text = FormatCurrency((Cost_of_Item() + q).ToString("0.00"))
        End If
    End Sub

    Sub Change()
        Dim tax, q, c As Double
        tax = 2.0

        If DataGridView1.Rows.Count > 0 Then


            q = ((Cost_of_Item() * tax) / 100) + Cost_of_Item()
            c = Val(lblCash.Text)

            lblChange.Text = FormatCurrency((c - q).ToString("0.00"))
        End If
    End Sub





    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click
        lblChange.Text = ""
        lblCash.Text = "0"
        lblSubTotal.Text = ""
        lblTax.Text = ""
        lblTotal.Text = ""
        cboPayment.Text = ""
        DataGridView1.Rows.Clear()
        DataGridView1.Refresh()

    End Sub

    Private Sub NumbersOnly(sender As Object, e As EventArgs) Handles btn1.Click, btn2.Click, btn3.Click, btn4.Click, btn5.Click, btn6.Click, btn9.Click, btn8.Click, btn0.Click, BtnDot.Click, btn7.Click
        Dim b As Button = sender

        If (lblCash.Text = "0") Then
            lblCash.Text = ""
            lblCash.Text = b.Text

        ElseIf (b.Text = ".") Then
            If (Not lblCash.Text.Contains(".")) Then
                lblCash.Text = lblCash.Text + b.Text
            End If
        Else
            lblCash.Text = lblCash.Text + b.Text
        End If

    End Sub

    Private Sub btnC_Click(sender As Object, e As EventArgs) Handles btnC.Click
        lblCash.Text = "0"
        cboPayment.Text = ""
        lblChange.Text = ""
        cboPayment.Text = ""

    End Sub

    Private Sub Cashier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboPayment.Items.Add("Cash")
        cboPayment.Items.Add("Debit")
        cboPayment.Items.Add("Credit")
        cboPayment.Items.Add("Gcash/Maya")
    End Sub

    Private Sub BtnPay_Click(sender As Object, e As EventArgs) Handles BtnPay.Click

        Try

            SerialPort1.PortName = "COM3"
            SerialPort1.Open()
            SerialPort1.Write("Open")
            SerialPort1.Close()
            MsgBox("Cash Drawer opened,Please close after opening")
        Catch ex As Exception

        End Try





        If (cboPayment.Text = "Cash") Then
            Change()

        Else
            lblChange.Text = ""
            lblCash.Text = ""
        End If
    End Sub

    Private Sub BtnRemove_Click(sender As Object, e As EventArgs) Handles BtnRemove.Click

        For Each row As DataGridViewRow In DataGridView1.SelectedRows
            DataGridView1.Rows.Remove(row)
        Next
        AddCost()
        If (cboPayment.Text = "Cash") Then
            Change()

        Else
            lblChange.Text = ""
            lblCash.Text = ""
        End If

    End Sub

    Private Sub btnBk_Click(sender As Object, e As EventArgs) Handles btnBk.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Boston Kreme" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Boston Kreme", "1", CostOfItem)
        AddCost()

    End Sub

    Private Sub btnCm_Click(sender As Object, e As EventArgs) Handles btnCm.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Choco Marble" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Choco Marble", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnNc_Click(sender As Object, e As EventArgs) Handles btnNc.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Nutty Choco" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Nutty Choco", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnBf_Click(sender As Object, e As EventArgs) Handles btnBf.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Bavarian Filled" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Bavarian Filled", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnSr_Click(sender As Object, e As EventArgs) Handles btnSr.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Sugar Raised" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Sugar Raised", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnCB_Click(sender As Object, e As EventArgs) Handles btnCB.Click
        Dim CostOfItem As Double = 30.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Choco Butternut" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Choco Butternut", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnBbc_Click(sender As Object, e As EventArgs) Handles btnBbc.Click
        Dim CostOfItem As Double = 30.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Blueberry Cheesecake" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Blueberry Cheesecake", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnQd_Click(sender As Object, e As EventArgs) Handles btnQd.Click
        Dim CostOfItem As Double = 30.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Quezo Duo" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Quezo Duo", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnCg_Click(sender As Object, e As EventArgs) Handles btnCg.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Choco Glazed" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Choco Glazed", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnS_Click(sender As Object, e As EventArgs) Handles btnS.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Sansribav" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Sansribav", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnHnc_Click(sender As Object, e As EventArgs) Handles btnHnc.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Ham and Cheese" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Ham and Cheese", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnCbnm_Click(sender As Object, e As EventArgs) Handles btnCbnm.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Cheesy Bacon and Mushroom" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Cheesy Bacon and Mushroom", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnSs_Click(sender As Object, e As EventArgs) Handles btnSs.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Spanish Sausage" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Spanish Sausage", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnTs_Click(sender As Object, e As EventArgs) Handles btnTs.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Tuna Sandwich" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Tuna Sandwich", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnEac_Click(sender As Object, e As EventArgs) Handles btnEac.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Egg And Cheese" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Egg And Cheese", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnCl_Click(sender As Object, e As EventArgs) Handles btnCl.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Caffe Latte" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Caffe Latte", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnSl_Click(sender As Object, e As EventArgs) Handles btnSl.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Spanish Latte" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Spanish Latte", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnA_Click(sender As Object, e As EventArgs) Handles btnA.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Americcano" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Americcano", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnOj_Click(sender As Object, e As EventArgs) Handles btnOj.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Orange Juice" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Orange Juice", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub btnMj_Click(sender As Object, e As EventArgs) Handles btnMj.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Mango Juice" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Mango Juice", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub btnPj_Click(sender As Object, e As EventArgs) Handles btnPj.Click
        Dim CostOfItem As Double = 25.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value = "Pineapple Juice" Then
                row.Cells(1).Value = Double.Parse(row.Cells(1).Value + 1)
                row.Cells(2).Value = Double.Parse(row.Cells(1).Value) * CostOfItem
                AddCost()
                Exit Sub
            End If
        Next

        DataGridView1.Rows.Add("Pineapple Juice", "1", CostOfItem)
        AddCost()
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click
        PPD.Document = PD
        PPD.ShowDialog()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub lblCash_Click(sender As Object, e As EventArgs) Handles lblCash.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub lblSubTotal_Click(sender As Object, e As EventArgs) Handles lblSubTotal.Click

    End Sub

    Private Sub lblTax_Click(sender As Object, e As EventArgs) Handles lblTax.Click

    End Sub

    Private Sub lblTotal_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub

    Private Sub cboPayment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPayment.SelectedIndexChanged

    End Sub

    Private Sub lblChange_Click(sender As Object, e As EventArgs) Handles lblChange.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub


    Private Sub PD_BeginPrint(sender As Object, e As Printing.PrintEventArgs) Handles PD.BeginPrint
        Dim pagesetup As New PageSettings
        pagesetup.PaperSize = New PaperSize("Custom", 250, 500)
        PD.DefaultPageSettings = pagesetup
    End Sub


    Private Sub PD_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PD.PrintPage
        Dim f10 As New Font("Calibri", 10, FontStyle.Regular)
        Dim f14 As New Font("Calibri", 14, FontStyle.Regular)

        Dim centermargin As Integer = PD.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = PD.DefaultPageSettings.PaperSize.Width

        Dim right As New StringFormat
        Dim center As New StringFormat
        right.Alignment = StringAlignment.Far
        center.Alignment = StringAlignment.Center

        Dim line As String
        line = "-----------------------------------------------------------------------------"
        e.Graphics.DrawString("Dunk N' Dorlat", f14, Brushes.Black, centermargin, 5, center)
        e.Graphics.DrawString("LFP Foods Corp", f10, Brushes.Black, centermargin, 25, center)
        e.Graphics.DrawString("VAT REG TIN: 032-698-2364-3200", f10, Brushes.Black, centermargin, 60, center)
        e.Graphics.DrawString("TRIMEX  TROJAN BLDG", f10, Brushes.Black, centermargin, 35, center)
        e.Graphics.DrawString("LFP  SERVICE POS V4.0", f10, Brushes.Black, centermargin, 45, center)
        e.Graphics.DrawString(line, f10, Brushes.Black, 0, 100)


        Dim startDateAndTime As String = "Date of Transaction: " & DateTimePicker1.Value.ToString("yyyy-MM-dd")
        e.Graphics.DrawString(startDateAndTime, f10, Brushes.Black, centermargin, 75, center)

        Dim height As Integer
        Dim i As Long
        DataGridView1.AllowUserToAddRows = False
        For row As Integer = 0 To DataGridView1.RowCount - 1
            height += 15
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(1).Value.ToString, f10, Brushes.Black, 0, 100 + height)
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(0).Value.ToString, f10, Brushes.Black, 25, 100 + height)
            i = DataGridView1.Rows(row).Cells(2).Value
            DataGridView1.Rows()(row).Cells(2).Value = Format(i, "##,##0")
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(2).Value.ToString, f10, Brushes.Black, rightmargin, 100 + height, right)


        Next

        Dim height2 As Integer
        height2 = 110 + height
        e.Graphics.DrawString(line, f10, Brushes.Black, 0, height2)

       



        Dim font As New Font("Calibri", 10, FontStyle.Regular)
        Dim brush As New SolidBrush(Color.Black)
        Dim startY As Integer = height2 + 20


        Dim cashierNameText As String = "Cashier: " & CashierName.Text
        e.Graphics.DrawString(cashierNameText, font, brush, 10, startY)


        Dim choicesText As String = "Choices: " & Choices.Text
        e.Graphics.DrawString(choicesText, font, brush, 10, startY + 30)


        Dim subtotalText As String = "Subtotal: " & lblSubTotal.Text
        e.Graphics.DrawString(subtotalText, font, brush, 10, startY + 60)


        Dim taxText As String = "Tax: " & lblTax.Text
        e.Graphics.DrawString(taxText, font, brush, 10, startY + 90)


        Dim totalText As String = "Total: " & lblTotal.Text
        e.Graphics.DrawString(totalText, font, brush, 10, startY + 120)


        Dim paymentText As String = "Payment Method: " & cboPayment.Text
        e.Graphics.DrawString(paymentText, font, brush, 10, startY + 150)


        Dim costText As String = "Cost: " & lblCash.Text
        e.Graphics.DrawString(costText, font, brush, 10, startY + 180)


        Dim changeText As String = "Change: " & lblChange.Text
        e.Graphics.DrawString(changeText, font, brush, 10, startY + 210)
    End Sub



    Private Sub PrintDocument1_PrintPage_1(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 10, 10)


        Dim font As New Font("Arial", 12)
        Dim brush As New SolidBrush(Color.Black)
        Dim startY As Integer = DataGridView1.Height + 20


        Dim subtotalText As String = "Subtotal: " & lblSubTotal.Text
        e.Graphics.DrawString(subtotalText, font, brush, 10, startY)


        Dim taxText As String = "Tax: " & lblTax.Text
        e.Graphics.DrawString(taxText, font, brush, 10, startY + 30)


        Dim totalText As String = "Total: " & lblTotal.Text
        e.Graphics.DrawString(totalText, font, brush, 10, startY + 60)

        Dim paymentText As String = "Payment Method: " & cboPayment.Text
        e.Graphics.DrawString(paymentText, font, brush, 10, startY + 90)


        Dim costText As String = "Cost: " & lblCash.Text
        e.Graphics.DrawString(costText, font, brush, 10, startY + 120)


        Dim changeText As String = "Change: " & lblChange.Text
        e.Graphics.DrawString(changeText, font, brush, 10, startY + 150)
    End Sub

    Private Sub PrintDocument1_BeginPrint(sender As Object, e As PrintEventArgs) Handles PrintDocument1.BeginPrint

    End Sub

    Private Sub Choices_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Choices.SelectedIndexChanged

    End Sub

    Private Sub CashierName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CashierName.SelectedIndexChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub

    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LoginForm.Show()
        Me.Close()
    End Sub

    Private Sub PrintPreviewDialog1_Load(sender As Object, e As EventArgs) Handles PrintPreviewDialog1.Load

    End Sub


    Private Sub ExportToExcelUsingEPPlus()
        Try
            Using package As New ExcelPackage()
                Dim worksheet = package.Workbook.Worksheets.Add("Sheet1")


                worksheet.Cells(1, 1).Value = "Date of Transaction"
                worksheet.Cells(1, 2).Value = "Item"
                worksheet.Cells(1, 3).Value = "Quantity"
                worksheet.Cells(1, 4).Value = "Amount"
                worksheet.Cells(1, 5).Value = "Total"
                worksheet.Cells(1, 6).Value = "Payment Method"


                Dim rowIndex As Integer = 2
                For i As Integer = 0 To DataGridView1.Rows.Count - 1
                    worksheet.Cells(rowIndex, 1).Value = DateTimePicker1.Value.ToString("yyyy-MM-dd")
                    worksheet.Cells(rowIndex, 2).Value = DataGridView1.Rows(i).Cells(0).Value.ToString()
                    worksheet.Cells(rowIndex, 3).Value = DataGridView1.Rows(i).Cells(1).Value.ToString()
                    worksheet.Cells(rowIndex, 4).Value = DataGridView1.Rows(i).Cells(2).Value.ToString()
                    worksheet.Cells(rowIndex, 5).Value = lblTotal.Text
                    worksheet.Cells(rowIndex, 6).Value = cboPayment.Text

                    rowIndex += 1
                Next


                Dim saveFileDialog As New SaveFileDialog()
                saveFileDialog.Filter = "Excel Workbook|*.xlsx"
                saveFileDialog.Title = "Save As"
                saveFileDialog.ShowDialog()

                If Not String.IsNullOrEmpty(saveFileDialog.FileName) Then
                    Dim fileInfo As New FileInfo(saveFileDialog.FileName)
                    package.SaveAs(fileInfo)
                    MessageBox.Show("Export successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error exporting to Excel: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnExportToExcel_Click(sender As Object, e As EventArgs) Handles BtnExportToExcel.Click
        ExportToExcelUsingEPPlus()
    End Sub
End Class
