﻿Imports MySql.Data.MySqlClient
Public Class Inventory
    Dim conn As MySqlConnection = New MySqlConnection("server=localhost;port=3306;username=root;password=;database=inventory")
    Dim cmd As New MySqlCommand
    Dim dt As New DataTable
    Dim da As New MySqlDataAdapter
    Dim dr As MySqlDataReader


    Private Sub BtnInsert_Click(sender As Object, e As EventArgs) Handles BtnInsert.Click

        Try
            conn.Open()
            Dim query As String
            query = "insert into listitem(Deals,Flavors,Quantity)values (@Deals,@Flavors,@Quantity)"
            cmd = New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@Deals", TxtDeals.Text)
            cmd.Parameters.AddWithValue("@Flavors", TxtFlavors.Text)
            cmd.Parameters.AddWithValue("Quantity", TxtQuantity.Text)
            cmd.ExecuteNonQuery()
            MsgBox("Product Added Successfully", MsgBoxStyle.Information, "Success")

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click
        Try
            conn.Open()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Update listitem set Deals='" & TxtDeals.Text & "',Flavors='" & TxtFlavors.Text & "',Quantity='" & TxtQuantity.Text & "' where ID='" & TxtID.Text & "'"
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Updated", MsgBoxStyle.Information, "Success")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try


    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        Try
            conn.Open()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Delete from listitem where Flavors = '" & TxtID.Text & "'"
            cmd.ExecuteNonQuery()
            MsgBox("Item Deleted")

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
        loadData()

    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        Try
            conn.Open()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from listitem Where Flavors='" & TxtID.Text & "'"
            dr = cmd.ExecuteReader
            If Not dr Is Nothing Then
                dr.Read()

                TxtDeals.Text = dr("Deals").ToString
                TxtFlavors.Text = dr("Flavors").ToString
                TxtQuantity.Text = dr("Quantity").ToString

                dr.Close()
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try
    End Sub

    Sub loadData()
        Try
            conn.Open()
            With cmd
                .Connection = conn
                .CommandText = "select * from listitem"
            End With
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            DataGridView1.DataSource = dt


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try
    End Sub

    Private Sub DGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub BtnCLear_Click(sender As Object, e As EventArgs) Handles BtnCLear.Click

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        loadData()

    End Sub
End Class
