﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CBMonth = New System.Windows.Forms.ComboBox()
        Me.CBday = New System.Windows.Forms.ComboBox()
        Me.CBYear = New System.Windows.Forms.ComboBox()
        Me.CBMethod = New System.Windows.Forms.ComboBox()
        Me.BtnShow = New System.Windows.Forms.Button()
        Me.BtnPrint = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(15, 14)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(468, 486)
        Me.DataGridView1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(523, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 44)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Month"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(523, 177)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 44)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Day"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(523, 255)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 44)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Year"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(523, 326)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(153, 44)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Method"
        '
        'CBMonth
        '
        Me.CBMonth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBMonth.FormattingEnabled = True
        Me.CBMonth.Items.AddRange(New Object() {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"})
        Me.CBMonth.Location = New System.Drawing.Point(708, 114)
        Me.CBMonth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CBMonth.Name = "CBMonth"
        Me.CBMonth.Size = New System.Drawing.Size(217, 33)
        Me.CBMonth.TabIndex = 6
        '
        'CBday
        '
        Me.CBday.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBday.FormattingEnabled = True
        Me.CBday.Items.AddRange(New Object() {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        Me.CBday.Location = New System.Drawing.Point(708, 188)
        Me.CBday.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CBday.Name = "CBday"
        Me.CBday.Size = New System.Drawing.Size(217, 33)
        Me.CBday.TabIndex = 7
        '
        'CBYear
        '
        Me.CBYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBYear.FormattingEnabled = True
        Me.CBYear.Items.AddRange(New Object() {"2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033"})
        Me.CBYear.Location = New System.Drawing.Point(708, 267)
        Me.CBYear.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CBYear.Name = "CBYear"
        Me.CBYear.Size = New System.Drawing.Size(217, 33)
        Me.CBYear.TabIndex = 8
        '
        'CBMethod
        '
        Me.CBMethod.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBMethod.FormattingEnabled = True
        Me.CBMethod.Items.AddRange(New Object() {"Cash", "Debit", "Credit", "Gcash/Maya"})
        Me.CBMethod.Location = New System.Drawing.Point(708, 338)
        Me.CBMethod.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CBMethod.Name = "CBMethod"
        Me.CBMethod.Size = New System.Drawing.Size(217, 33)
        Me.CBMethod.TabIndex = 9
        '
        'BtnShow
        '
        Me.BtnShow.Location = New System.Drawing.Point(564, 425)
        Me.BtnShow.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnShow.Name = "BtnShow"
        Me.BtnShow.Size = New System.Drawing.Size(143, 64)
        Me.BtnShow.TabIndex = 10
        Me.BtnShow.Text = "Show"
        Me.BtnShow.UseVisualStyleBackColor = True
        '
        'BtnPrint
        '
        Me.BtnPrint.Location = New System.Drawing.Point(747, 425)
        Me.BtnPrint.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Size = New System.Drawing.Size(143, 64)
        Me.BtnPrint.TabIndex = 11
        Me.BtnPrint.Text = "Print"
        Me.BtnPrint.UseVisualStyleBackColor = True
        '
        'Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1125, 626)
        Me.Controls.Add(Me.BtnPrint)
        Me.Controls.Add(Me.BtnShow)
        Me.Controls.Add(Me.CBMethod)
        Me.Controls.Add(Me.CBYear)
        Me.Controls.Add(Me.CBday)
        Me.Controls.Add(Me.CBMonth)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Reports"
        Me.Text = "Reports"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CBMonth As System.Windows.Forms.ComboBox
    Friend WithEvents CBday As System.Windows.Forms.ComboBox
    Friend WithEvents CBYear As System.Windows.Forms.ComboBox
    Friend WithEvents CBMethod As System.Windows.Forms.ComboBox
    Friend WithEvents BtnShow As System.Windows.Forms.Button
    Friend WithEvents BtnPrint As System.Windows.Forms.Button
End Class
