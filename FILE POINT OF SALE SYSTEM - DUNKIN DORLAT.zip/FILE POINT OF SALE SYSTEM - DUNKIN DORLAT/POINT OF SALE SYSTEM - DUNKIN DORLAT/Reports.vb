﻿Imports System.Data.SqlClient
Imports System.IO
Imports OfficeOpenXml

Public Class Reports

    Private excelFilePath As String = "Path\To\Your\Excel\File.xlsx"

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub CBMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBMonth.SelectedIndexChanged

    End Sub

    Private Sub CBday_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBday.SelectedIndexChanged

    End Sub

    Private Sub CBYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBYear.SelectedIndexChanged

    End Sub

    Private Sub CBMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBMethod.SelectedIndexChanged

    End Sub

    Private Sub BtnShow_Click(sender As Object, e As EventArgs) Handles BtnShow.Click

        Using package As New ExcelPackage(New FileInfo(excelFilePath))

            Dim worksheet = package.Workbook.Worksheets(0)


            Dim totalRows = worksheet.Dimension.End.Row


            Dim dataTable As New DataTable()

            For col = 1 To worksheet.Dimension.End.Column
                dataTable.Columns.Add(worksheet.Cells(1, col).Value.ToString())
            Next


            For row = 2 To totalRows
                Dim newRow = dataTable.NewRow()

                For col = 1 To worksheet.Dimension.End.Column
                    newRow(col - 1) = worksheet.Cells(row, col).Value
                Next

                dataTable.Rows.Add(newRow)
            Next


            DataGridView1.DataSource = dataTable
        End Using
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click

    End Sub
End Class
